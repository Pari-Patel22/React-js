import React from 'react'
import LocalCruds from './Components/LocalCruds'
import Cruds from './Components/Cruds'

export default function App() {
  return (
    <div>
      <LocalCruds/>
      <Cruds/>
    </div>
  )
}
